place and run in your NEOTOKYO folder...

this fixes your NT source icon in your tray.

by 2cwldys